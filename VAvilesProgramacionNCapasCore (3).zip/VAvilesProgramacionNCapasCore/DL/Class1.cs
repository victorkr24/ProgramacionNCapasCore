﻿namespace DL
{
    public class Class1
    {

    }
}